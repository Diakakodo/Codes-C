#include <math.h>
#include <stdio.h>
int MirorGD(int N,int nb);
int NbDigit(int N);

void NbMiroir();

int power_of_two(int a);
unsigned int ExpoNaiveIte(unsigned int g,unsigned int e,unsigned int n);
unsigned int ExpoPuiss2(unsigned int g,unsigned int e,unsigned int n);
