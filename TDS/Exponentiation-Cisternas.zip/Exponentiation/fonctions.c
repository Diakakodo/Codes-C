#include "fonctions.h"

int NbDigit(int N){
	
    int c=0;
    do{
        N/=10;
        c++;
    }while(N>0);
    return c;
}

int MirorGD(int N,int nb){
	int reste=0,puissance,puissance2,x=0,resultat=0;
	
	while(nb!=0){
		puissance=pow(10,nb-1);
		puissance2=pow(10,x);
		reste=N/puissance;
		N-=reste*puissance;
		resultat+=reste*puissance2;
		nb--;
		x++;
		
	}
	return resultat;	
}	
void NbMiroir(){
	int N,nb;
	printf("Entrez un nombre\n");
	scanf("%d",&N);
	nb=NbDigit(N);
	N=MirorGD(N,nb);
	printf("%d\n",N);	
}

unsigned int ExpoNaiveIte(unsigned int g,unsigned int e,unsigned int n){
	int i;
	unsigned int resultat=1;
	for(i=1;i<=e;i++){
		
		resultat*=g;
		resultat%=n;
	}
				
	return resultat;
}

int power_of_two(int a){
    if(a%2 != 0) return 0;
    else if(a == 2) return 1;
    else return power_of_two(a/2);
}

		
}
unsigned int ExpoPuiss2(unsigned int g,unsigned int e,unsigned int n){
	
	if(e==1)
		return g;
	
	g%=n;
	return ExpoPuiss2(g*g,e/2,n);	
}

