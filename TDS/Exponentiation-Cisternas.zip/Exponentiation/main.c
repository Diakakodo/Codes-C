
#include "fonctions.h"

int main(){	
	unsigned int g=5,e=4,n=5;	
	printf("%d\n",ExpoPuiss2(g,e,n));		
	return 0;
}
